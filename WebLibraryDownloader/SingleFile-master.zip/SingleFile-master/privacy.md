# Privacy Policy
Your data always belongs to you, and only you. SingleFile does not collect any data.

## How your data is protected and used
SingleFile does not send any data to our servers or any third parties. All your data is processed and stored locally on your device.

## Customer support
When you request for customer support, we may ask for your email address to get back to you.

## Changes to our privacy policy
We keep our privacy notice under regular review and we will place any updates on this document. This privacy notice was last updated on April 2019.

## How to contact us
Please contact us if you have any questions about our privacy policy by email to gildas.lormeau &lt;at&gt; gmail.com.

## History
cf. https://github.com/gildas-lormeau/SingleFile/commits/master/privacy.md
